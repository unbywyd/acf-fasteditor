
/*******************************************
*  This release generated using ungic.
********************************************/
  Release name: app
  Release version: 1
  Release date: 26.10.2021, 10:01
  Project name: client
  Project version: 1.0.0
  Author: unbyw